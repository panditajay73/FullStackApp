import { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { loginUser } from '../redux/authSlice';
import { useNavigate, Link } from 'react-router-dom';
import '../css/LoginForm.css';

export default function LoginForm() {
    const [credentials, setCredentials] = useState({ usernameOrEmail: '', password: '' });
    const { loading, error } = useSelector(state => state.auth);
    const dispatch = useDispatch();
    const navigate = useNavigate();

    const handleSubmit = (e) => {
        e.preventDefault();
        dispatch(loginUser(credentials)).then((res) => {
            if (res.meta.requestStatus === 'fulfilled') {
                navigate('/dashboard'); // Redirects to Dashboard on success
            }
        });
    };

    return (
        <div className="login-container">
            <div className="login-box">
                <h2>Login</h2>
                {error && <p className="error-text">{error}</p>}
                <form onSubmit={handleSubmit}>
                    <input
                        type="text"
                        placeholder="Username or Email"
                        value={credentials.usernameOrEmail}
                        onChange={(e) => setCredentials({ ...credentials, usernameOrEmail: e.target.value })}
                        required
                    />
                    <input
                        type="password"
                        placeholder="Password"
                        value={credentials.password}
                        onChange={(e) => setCredentials({ ...credentials, password: e.target.value })}
                        required
                    />
                    <div className="forgot-password-container">
                        <Link to="/forgot-password" className="forgot-password-link">Forgot Password?</Link>
                    </div>
                    <button type="submit" disabled={loading}>
                        {loading ? 'Logging in...' : 'Login'}
                    </button>
                </form>
                <p className="signup-link">
                    Not registered? <Link to="/signup">Create an account</Link>
                </p>
            </div>
        </div>
    );
}
