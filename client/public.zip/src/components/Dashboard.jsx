import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { logout } from '../redux/authSlice';
import { useNavigate } from 'react-router-dom';
import { FaUserCircle } from 'react-icons/fa';
import ChangePassword from './ChangePassword';
import '../css/Dashboard.css';

export default function Dashboard() {
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const [showChangePassword, setShowChangePassword] = useState(false);
    const [menuOpen, setMenuOpen] = useState(false);

    const username = useSelector(state => state.auth.username) || "User";
    const role = useSelector(state => state.auth.role) || "Guest";

    const handleLogout = () => {
        dispatch(logout());
        navigate('/');
    };

    const refreshDashboard = () => {
        window.location.reload();
    };
    

    return (
        <div className="dashboard-container">
            {/* Navbar */}
            <nav className="dashboard-nav">
                <div className="nav-logo" onClick={refreshDashboard} style={{ cursor: 'pointer' }}>
                    🚀 Project Dashboard
                </div>
                <div className="user-info">
                    <span className="username">Welcome, {username}.</span>
                    <span className={`role-badge ${role.toLowerCase()}`}>{role}</span>
                    <FaUserCircle className="user-icon" onClick={() => setMenuOpen(!menuOpen)} />
                </div>
            </nav>

            {/* Dropdown List */}
            {menuOpen && (
                <div style={{
                    position: 'absolute',
                    top: '100px',
                    right: '20px',
                    background: 'white',
                    boxShadow: '0px 4px 6px rgba(0, 0, 0, 0.1)',
                    borderRadius: '8px',
                    padding: '10px',
                    display: 'flex',
                    flexDirection: 'column',
                    zIndex: 1000
                }}>
                    <button 
                        style={{
                            background: 'none',
                            border: 'none',
                            padding: '10px',
                            cursor: 'pointer',
                            textAlign: 'left',
                            fontWeight: 'bold'
                        }}
                        onClick={() => { setShowChangePassword(true); setMenuOpen(false); }}>
                        Change Password
                    </button>
                    <button 
                        style={{
                            background: 'none',
                            border: 'none',
                            padding: '10px',
                            cursor: 'pointer',
                            textAlign: 'left',
                            color: 'red',
                            fontWeight: 'bold'
                        }}
                        onClick={handleLogout}>
                        Logout
                    </button>
                </div>
            )}

            {/* Main Dashboard Content */}
            <div className="dashboard-content">
                <h1>Welcome, {username}!</h1>
                <h3 className="user-role">Role: <span className={`role-badge ${role.toLowerCase()}`}>{role}</span></h3>
                <p>Your tools and projects at a glance.</p>

                {/* Render Change Password Component if selected */}
                {showChangePassword ? <ChangePassword /> : (
                    <div className="dashboard-cards">
                        <div className="card">
                            <h3>📁 Project Management</h3>
                            <p>Track and manage your tasks.</p>
                        </div>
                        <div className="card">
                            <h3>📊 Reports & Analytics</h3>
                            <p>View detailed project insights.</p>
                        </div>
                        <div className="card">
                            <h3>⚙️ Settings</h3>
                            <p>Customize your preferences.</p>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
}
