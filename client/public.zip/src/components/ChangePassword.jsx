import React, { useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import { changePassword, logout } from "../redux/authSlice"; // Import logout action
import { FaEye, FaEyeSlash } from "react-icons/fa";
import "../css/ChangePassword.css"; // Import external CSS

export default function ChangePassword() {
    const dispatch = useDispatch();
    const username = useSelector(state => state.auth.username) || "User";
    const error = useSelector(state => state.auth.error);
    const success = useSelector(state => state.auth.success);

    const [oldPassword, setOldPassword] = useState("");
    const [newPassword, setNewPassword] = useState("");
    const [confirmPassword, setConfirmPassword] = useState("");
    const [showOld, setShowOld] = useState(false);
    const [showNew, setShowNew] = useState(false);
    const [showConfirm, setShowConfirm] = useState(false);
    const [updating, setUpdating] = useState(false);

    const handleSubmit = (e) => {
        e.preventDefault();

        if (newPassword !== confirmPassword) {
            alert("New password and confirm password do not match!");
            return;
        }

        setUpdating(true);

        dispatch(changePassword({ username, oldPassword, newPassword }))
            .then(() => {
                setTimeout(() => {
                    setUpdating(false);
                    dispatch(logout()); // Logout after 1 second
                }, 1000);
            });
    };

    return (
        <div className="change-password-container">
            <h2>🔐 Change Password</h2>

            {error && <p className="error">{error}</p>}
            {success && <p className="success">{success}</p>}

            <form onSubmit={handleSubmit}>
                <input type="hidden" value={username} readOnly />

                <div className="input-group">
                    <label>Current Password</label>
                    <div className="password-wrapper">
                        <input
                            type={showOld ? "text" : "password"}
                            placeholder="Current Password"
                            value={oldPassword}
                            onChange={(e) => setOldPassword(e.target.value)}
                            required
                        />
                        <span onClick={() => setShowOld(!showOld)}>
                            {showOld ? <FaEyeSlash /> : <FaEye />}
                        </span>
                    </div>
                </div>

                <div className="input-group">
                    <label>New Password</label>
                    <div className="password-wrapper">
                        <input
                            type={showNew ? "text" : "password"}
                            placeholder="New Password"
                            value={newPassword}
                            onChange={(e) => setNewPassword(e.target.value)}
                            required
                        />
                        <span onClick={() => setShowNew(!showNew)}>
                            {showNew ? <FaEyeSlash /> : <FaEye />}
                        </span>
                    </div>
                </div>

                <div className="input-group">
                    <label>Confirm Password</label>
                    <div className="password-wrapper">
                        <input
                            type={showConfirm ? "text" : "password"}
                            placeholder="Confirm Password"
                            value={confirmPassword}
                            onChange={(e) => setConfirmPassword(e.target.value)}
                            required
                        />
                        <span onClick={() => setShowConfirm(!showConfirm)}>
                            {showConfirm ? <FaEyeSlash /> : <FaEye />}
                        </span>
                    </div>
                </div>

                <button type="submit" className="update-btn" disabled={updating}>
                    {updating ? "Updating..." : "Update Password"}
                </button>
            </form>
        </div>
    );
}
